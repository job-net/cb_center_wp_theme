The JavaScript code at `../../javascript/script.js` will be processed by
esbuild, and the output file will be created in this folder as `script.min.js`
and enqueued in `../functions.php`.

DO NOT directly edit `script.min.js`, as it is ignored by git and will be
overwritten the next time esbuild runs.
