<div class="basis-1/3">
	<div class="flex flex-col space-y-4 shadow-md rounded-2xl p-4">

		<div class="bg-gray-50 flex flex-row rounded-xl overflow-hidden">
			<div class="basis-1/4">
				<img class="company_logo" src="http://cb.test/wp-content/uploads/2023/01/cbcgtblue-150x150.png"
					 alt="CB Center">
			</div>
			<div class="basis-3/4 p-4">
				<div class="text-xs">
					<strong>CB Center</strong></div>
				<div class="text-xs">

					<a href="http://cb.test" rel="nofollow" target="_blank">Web</a>
				</div>

				<div class="text-xs">
					@<a href="https://twitter.com/cbcentergt" class="company_twitter">cbcentergt</a></div>
			</div>
		</div>
		<div class="">
			<p class="text-gray-400">Encuentra el empleo perfecto para ti</p></div>
	</div>
</div>
