<?php
/**
 * xxxx
 *
 * This template can be overridden by copying it to yourtheme/wp-job-manager-applications/application-form-applied.php.
 *
 * @see         https://wpjobmanager.com/document/template-overrides/
 * @author      Automattic
 * @package     WP Job Manager - Applications
 * @category    Template
 * @version     2.0.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// Intentionally blank
?>
